﻿namespace AuctionService.Entities.Domain
{
    public enum Status
    {
        Live,
        Finished,
        ReserveNotMet
    }
}
